#include <bits/stdc++.h>
using namespace std;
//__builtin_popcount(n) amount of "1" bits
// log2(num & -num); rightmost bit, first bit pos
// log2(num & num); leftmost bit
//  num/ (-num & num) num without trailing zeroes 10000 = 1 not 16
//
// mask|(1<<i); modify number mask ith bit
//
//for (int i = 0; i < pow(2,n); i++){
//    for (int j = 0; j < n; j++){
//        if ((i >> j) & 1){
//            cout << 'f';
//        }else{
//            cout << 'f';
//        }
//    }
//}
// ceil(a/b) -> (a+b-1)/b
//        scanf("%lld",&n);
//         fill(all(vec), 100);
#define ll long long
#define ld long double
//#define mod 1000000007
#define mod 998244353
#define ull unsigned long long
#define fbo(a) find_by_order(a) //will give a-th largest element
#define ook(a) order_of_key(a) //will give no. of elements strictly lesser than a
#define setbits(x)      __builtin_popcountll(x)
#define str string
#define fo(i,a,n) for(ll i=a;i<n;i++)
#define eb emplace_back
#define all(a) a.begin(),a.end()
#define allr(a) a.rbegin(),a.rend()
#define ff first
#define ss second
#define pb push_back
#define sp(x,y)         fixed<<setprecision(y)<<x
#define nl '\n'
#define inf (1LL<<62)
#define si(x)    scanf("%d",&x)
#define sl(x)    scanf("%lld",&x)
#define sss(s)    scanf("%s",s)
#define pi(x) printf("%d\n",x)
#define pl(x)    printf("%lld\n",x)
#define ps(s)    printf("%s\n",s)
#define FOR(a, c, b) for (int a = c; a < b; a++)
#define MIN3(a, b, c) std::min(std::min(a, c))

typedef map<ll, ll> mll;
typedef vector<long long> vll;
typedef pair<ll, ll> pll;
typedef vector<pll> vpll;
typedef vector<vector<ll> > vvll;

void printArr(vll arr) {
    for (ll x : arr) cout << x << " ";
    cout << '\n';
}
inline bool get_bit(ll &x, ll &bt) { return (x >> bt) & 1; }

struct place{
    ll i,j,time;
    bool operator<(const place& c1)const{
        return time < c1.time;
    }
    //    bool operator==(const cow&c1)const{
    //        if (c == c1.c) return true;
    //        return false;
    //    }
    //    bool operator!=(const cow&c1)const{
    //        if (c == c1.c) return false;
    //        return true;
    //    }
};


//double dist(ll y1, ll x1, ll y2, ll x2) {
//
//    ll dd = (y1 - y2)*(y1 - y2);
//    ll d2 = (x1 - x2)*(x2-x1);
//    double ret = sqrt(dd + d2);
//    return ret;
//}

ll dist(ll y1, ll x1, ll y2, ll x2) { return abs(y2 - y1) + abs(x2 - x1); }

int main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);

    ll g, n;
    cin >> g >> n;
    set<place> grazes;

    for(int i = 0; i < g; i++)
    {
        ll x, y, t;
        cin >> x >> y >> t;
        place add; add.j = x; add.i = y; add.time = t;
        grazes.emplace(add);
    }
    vector<place> cws;
    for(int i = 0; i < n; i++)
    {
        ll x, y, t;
        cin >> x >> y >> t;
        place add; add.j = x; add.i = y; add.time = t;
        cws.emplace_back(add);
    }

    ll c = 0;
    for(place cw : cws)
    {
        auto ptrnxt = grazes.lower_bound(cw);
        place nxt = *ptrnxt;

        bool n = true;
        ll dt = nxt.time - cw.time;
        if(ptrnxt == grazes.end()) n = true;
        else if(dist(nxt.i, nxt.j, cw.i, cw.j) > dt) n = false;

        bool p = true;
        if(ptrnxt != grazes.begin()) {
            place prv = *prev(ptrnxt);
            dt = cw.time - prv.time;
            ll d2 = dist(prv.i, prv.j, cw.i, cw.j);
            bool t1 = d2 > dt;
            if (dist(prv.i, prv.j, cw.i, cw.j) > dt) p = false;
        }
        if(n && p);
        else{
            c++;
        }
    }

    cout << c << endl;

    return 0;
}
#if 0

2 4
0 0 100
50 0 200
0 50 50
1000 1000 0
50 0 200
10 0 170

#endif
#if 0
remove all people on time
    count all cookies and muffins
    continually decrement the greater of the two by one until someone is content
        sorting by shortest waiting time
        removing just enough to make them ok
        go to next person
    remove content person
    recalculate
    continue until no one is left
#endif
