#include <bits/stdc++.h>
using namespace std;
#define eb emplace_back();
typedef long long ll;
typedef vector<ll> vll;
typedef vector<vector<ll>> vvll;

struct flight{
    ll leave, dest, time, org;
    bool operator<(const flight &a)const{
        return time < a.time;
    }
    bool operator==(const flight &a)const{
        return (leave == a.leave && dest == a.dest && time == a.time && org == a.org);
    }
    bool operator!=(const flight &a)const{
        return (leave != a.leave || dest != a.dest || time != a.time || org != a.org);
    }
};

ll bfs(vector<vector<flight>> &paths, ll d, vll &lo)
{
    set<flight> flown;
    vector<flight> qu;
    vector<flight> nodes = paths[1];
    for(flight fl : nodes){
        if(fl.leave >= 0){
            qu.push_back(fl);
            flown.insert(fl);
        }
    }
    ll ans = 1000000002;
    while(!qu.empty()) {
        flight curr = *qu.begin();
        qu.erase(qu.begin());
        if (curr.dest == d) ans = min(ans, curr.time);
        vector<flight> add = paths[curr.dest];
        for (flight fl: add) {
            if (fl.leave >= curr.time + lo[curr.dest] && !binary_search(flown.begin(), flown.end(), fl)) {
                qu.eb(fl);
                flown.insert(fl);
            }
        }
    }
    return ans;
}

int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);

    //bfs with queue as a set ordered by shortest time -> priority queue

    ll n, m;
    cin >> n >> m;
    vector<vector<flight>> paths; vector<flight> add;
    for(int i = 0; i <= n; i++) paths.eb(add);
    for(int i = 0; i < m; i++){
        ll c, r, d, s; // 1st ap, time of flight, destination, arrival time
        cin >> c >> r >> d >> s;
        paths[c].push_back({r, d, s, c});
    }
    vll lo; lo.eb(0);
    for(int i = 1; i <= n; i++){
        ll d; cin >> d;
        lo.eb(d);
    }

    for(ll i = 1; i <= n; i++) {
        ll ans = bfs(paths, i, lo);
        if(i == 1 && ans > 0) cout << 0 << endl;
        else if(ans == 1000000002) cout << -1 << endl;
        else cout << ans << endl;
    }

    return 0;
}
#if 0
3 3
1 0 2 10
2 11 2 0
2 1 3 20
10 1 10
-> 0 + 0 + 20

3 3
1 0 2 10
2 10 2 0
2 1 3 20
10 1 10
-> 0 + 10 + -1
#endif